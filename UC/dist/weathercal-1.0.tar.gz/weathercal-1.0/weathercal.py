def convert(): 
    celsius = input("Enter your degrees in Celsius here: ")
    fahrenheit = 9/5 * int(celsius) + 32
    return fahrenheit
print(convert())

#def convert(): 
 #   celsius = input("Enter your degrees in Celsius here: ")
  #  def conv(celsius):
   #     celsius = 9/5 * int(celsius) + 32
   #     return celsius
   # fahrenheit = conv(celsius)
   # return str(fahrenheit)