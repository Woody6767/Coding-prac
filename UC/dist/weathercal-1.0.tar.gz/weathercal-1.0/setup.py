from setuptools import setup

setup(
 name='weathercal',
 version='1.0',
 description='The Head First Python Search Tools',
 author='HF Python 2e',
 url='headfirstlabs.com',
 py_modules=['weathercal'],
)